public class Empty {
  // Just an empty class
  // because gradle complained about not having any Java files to compile?
}
